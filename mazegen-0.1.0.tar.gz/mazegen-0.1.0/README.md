# A-Maze-ing Architecture

```mermaid
flowchart TD
    CLI[a_maze_ing.py] -->|load| Config[config.py]
    CLI -->|42 pattern| Pattern[pattern.py]
    CLI -->|start| Interactive[interactive.py]

    Config -->|config| Interactive
    Pattern -->|blocked cells| Interactive
    Interactive -->|generate| Generator[mazegen.MazeGenerator]
    Generator -->|grid and path| Interactive

    Interactive -->|grid, path, and cells| Renderer[renderer.py]
```

## Data Flow

1. `a_maze_ing.py` loads and validates the configuration through `config.py`.
2. It creates the closed-cell `42` pattern through `pattern.py`.
3. It passes the configuration and pattern cells into `interactive.py`.
4. `interactive.py` creates `MazeGenerator`, which returns the wall grid and
   the shortest entry-to-exit path.
5. `interactive.py` passes the grid, path, entry/exit, and pattern cells to
   `renderer.py`.
6. `renderer.py` draws the colored terminal maze and accepts state supplied by
   the interactive session.

## Building and Evaluating `mazegen`

Build the reusable package from the repository root:

```bash
make mazegen-release
```

This creates the required artifacts at the repository root:

```text
mazegen-0.1.0-py3-none-any.whl
mazegen-0.1.0.tar.gz
```

To prove that the application works with the installed package, create a
temporary copy of the application files without the local `mazegen/` source:

```bash
wheel="$PWD/mazegen-0.1.0-py3-none-any.whl"
evaluation_dir="$(mktemp -d)"
cp a_maze_ing.py config.py interactive.py pattern.py renderer.py config.txt \
    "$evaluation_dir"

cd "$evaluation_dir"
python3 -m venv .venv
.venv/bin/python -m pip install "$wheel"
.venv/bin/python a_maze_ing.py config.txt
```

The temporary directory has no local `mazegen/` folder, so this run can only
import the wheel installed in its virtual environment. The repository is not
modified; enter `q` to exit the interactive application.
